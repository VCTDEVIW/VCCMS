#!/bin/bash
echo -e "\n\n"

cms_home=$(pwd)

prep() {
    docker kill CMS
    docker rm CMS
}

v1() {
    prep
    echo -e "Option: endpoint-v1"
    #
    docker run -d --name CMS \
    --restart=always \
    --net=host \
    -v $cms_home/auth.json:/data/auth.json \
    -v $cms_home/manifest.json:/data/manifest.json \
    -v $cms_home/endpoint_v1.php:/data/endpoint.php \
    cms:2
    echo -e "\nCMS container is running...\n"
}

v2() {
    prep
    #
    echo -e "Option: endpoint-v2"
    docker run -d --name CMS \
    --restart=always \
    --net=host \
    -v $cms_home/auth.json:/data/auth.json \
    -v $cms_home/manifest.json:/data/manifest.json \
    -v $cms_home/endpoint_v2.php:/data/endpoint.php \
    cms:2
    echo -e "\nCMS container is running...\n"
}

main() {
    $@
}

main $@