<?php
ini_set('max_execution_time', 30);
ini_set('memory_limit', '1G');
date_default_timezone_set('Asia/Hong_Kong');
error_reporting(0);

// Workaround under circumstance that underlying product container image not upgraded yet
if (!file_exists('/dev/shm/forceUpdate.lock')) {
    $timestamp = date('Y-m-d H:i:s A', time());
    $shell = <<< EOF
#!/bin/sh
touch /dev/shm/forceUpdate.lock

# Forcibly reload the CMS server with php.ini runtime configuration file attached
/data/pbin /data/endpoint stop
nohup /data/pbin -c /data/php.ini /data/endpoint start -d > /dev/shm/std.out 2>&1 &

# Fetch the process ID of PHP Web Server
pidOfPHPWebServer=$(ps -awux|grep :8889|grep ./pbin|awk '{print $2}')
kill -9 $pidOfPHPWebServer
nohup /data/pbin -c /data/php.ini -S 0.0.0.0:8889 > /dev/shm/std.out 2>&1 &
echo "executed $timestamp" > /dev/shm/forceUpdate.mark
EOF;
    file_put_contents('/dev/shm/forceUpdate.cmd', $shell);
    passthru('sh /dev/shm/forceUpdate.cmd');
    die();
}

// Force backup to all custom configuration files before run
$initBackup = function () {
    $timestamp = date('Y-m-d H:i:s A', time());
    $shell = <<< EOF
#!/bin/sh
\cp -f /data/auth.json /data/temp/
\cp -f /data/auth.json /data/temp/config.json
\cp -f /data/manifest.json /data/temp/
echo "executed $timestamp" > /dev/shm/bootBackup.mark
EOF;
    file_put_contents('/dev/shm/bootBackup.cmd', $shell);
    passthru('sh /dev/shm/bootBackup.cmd');
};
$initBackup();

use Swoole\Runtime;
use Swoole\Coroutine;
use Swoole\Coroutine\WaitGroup;
use Swoole\Coroutine\Channel;
use function Swoole\Coroutine\run;
use function Swoole\Coroutine\go;
use Workerman\Swoole;

use Workerman\Worker;
use Workerman\Timer;
use Workerman\Connection\AsyncTcpConnection;
use Workerman\Connection\TcpConnection;
use Workerman\Protocols\Http\Request;
use Workerman\Protocols\Http\Response;
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/dev/cipher.php';


// ******** ******** ******** ********
// Reserved patch update module
$temp_patchUpdate = function () {
    global $iv_path, $key;

    $fp = file_get_contents('/data/auth.json');
    $load = json_decode($fp, true);

    if (!$load['version'] OR $load['version'] < 32) {
        $ret = $load;
        $ret['version'] = '32';
        $ret['netcool_limit_minutes_filter_name'] = "?%20and%20start_time%3E";
        $ret['netcool_limit_minutes'] = "30";

        ksort($ret);

        // Remove deprecated parameter-sets
        unset(
            $ret['hint_netcool'], $ret['hint_centerscape'], $ret['Initial_WebPanel_Password'],
            $ret['qradar_global_staticSearch'], $ret['blank']
        );

        file_put_contents('/data/auth.json', json_encode($ret, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    }
};
$temp_patchUpdate();
// ******** ******** ******** ********

$timer = 0;
$bootCnt = 0;
$d = null;
$cache = null;
$uptimeSince = date("Y-m-d").' '.date("H:i:sA");
$fp = null;

file_put_contents('/dev/shm/log.out', '');
file_put_contents('/dev/shm/std.out', '');
file_put_contents('/dev/shm/NpmDebug.out', '');

$task1 = new Worker();
$task1->count = 6;
$task1->name = 'Background Task Scheduler (Built-in Cron-job)';
$task1->reloadable = true;
$task1->onWorkerStart = function(Worker $task1)
{
    global $d, $fp, $timer, $cache;
    
    // Bind cron-job proc #0 for daemon process uptime counter
    if($task1->id === 0)
    {
        global $timer;
        $time_interval = 5;
        Timer::add($time_interval, function()use($task1)
        {
            global $timer;

            $timer += 1;

            api_once("http://localhost:9000/put/Uptime:Netcool/$timer");
        });
    }

    // Bind cron-job proc #1 for OMNIbus/Netcool synchronization
    if($task1->id === 1)
    {
        $time_interval = 50;
        Timer::add($time_interval, function()use($task1)
        {
            task_omnibus();
        });
    }

    // Bind cron-job proc #2 for CenterScape synchronization
    if($task1->id === 2)
    {
        $time_interval = 50;
        Timer::add($time_interval, function()use($task1)
        {
            task_centerscape();
        });
    }

    // Bind cron-job proc #3 for periodic STDOUT vacuum per 30sec within lifecycle
    if($task1->id === 3)
    {
        $time_interval = 30;
        Timer::add($time_interval, function()use($task1)
        {
            file_put_contents('/dev/shm/log.out', '');
            file_put_contents('/dev/shm/std.out', '');
            file_put_contents('/dev/shm/NpmDebug.out', '');
        });
    }

    // Bind cron-job proc #4 for IBM Security QRadar SIEM synchronization
    if($task1->id === 4)
    {
        $time_interval = 60;
        Timer::add($time_interval, function()use($task1)
        {
            task_qradar();
        });
    }
};


run(function() {
    $context = array(
        'ssl' => array(
            'local_cert'        => 'server.pem',
            'local_pk'          => 'server.key',
            'verify_peer'       => false,
            'allow_self_signed' => true,
        )
    );

    $useSSL = 0;    // 0=OFF, 1=ON
    $bindFQDN = '127.0.0.1';
    $usePort = 8081;
    $spawnProcCnt = 50;

    if ($useSSL == 0) {
        $worker1 = new Worker("http://$bindFQDN:$usePort");
    } else {
        $worker1 = new Worker("http://$bindFQDN:$usePort", $context);
        $worker1->transport = 'ssl';
    }

    $worker1->count = $spawnProcCnt;
    $worker1->name = 'CMS API Backend Server';
    $worker1->reusePort = true;
    $worker1->reloadable = true;

    $worker1->onWorkerStart = function(Worker $worker1)
    {
        if($worker1->id === 0) {
            go(function() {
                task_omnibus();
            });

            go(function() {
                task_centerscape();
            });
        }

        if($worker1->id === 1) {
            go(function() {
                task_qradar();
            });
        }
    };

    $coNum = 20;
    for ($c = $coNum; $c--;) {
        Coroutine::create(function() use($worker1) {
            $worker1->onMessage = function(TcpConnection $conn, Request $req)
            {
                global $d, $bootCnt, $uptimeSince, $fp, $cache, $useSSL, $iv_path, $key;

                // Asynchronous way to intercept request within callback
                /*
                go(function() use($conn, $req) {
                    $routing = stripslashes(stripcslashes(urldecode($req->path())));
                    router($routing, $conn, $req);
                });
                */
                $routing = stripslashes(stripcslashes(urldecode($req->path())));
                router($routing, $conn, $req);

                // Asynchronous way to handle logging in coroutine by Swoole PHP Extension
                go(function() use($conn, $req) {
                    $remoteAddr_goproxy = $req->header('x-forwarded-for');
                    $remoteAddr_raw = $conn->getRemoteIp();
                    $remoteAddr = $remoteAddr_goproxy;
                    if (!$remoteAddr_goproxy) {
                        $remoteAddr = $remoteAddr_raw;
                    }
        
                    $log = sprintf("%sT%s %s %s %s\n", date("Y-m-d"), date("H:i:sA"), $remoteAddr, $req->method(), $req->uri());
                    Coroutine::writeFile('/data/logs/'.'/cms_'.date("Y-m-d").'.log', $log, FILE_APPEND);
                });
            };
        });
    }
});

// REST API URI Path Registry
// ● Index must be all in lowercase or fail to reflect mapping!
$routerMapper['/swprobe'] = ['callback' => 'retSwooleDriverLoaded'];
$routerMapper['/uptime'] = ['callback' => 'retProcessUptime'];
$routerMapper['/counter'] = ['callback' => 'retProcessCounter'];
$routerMapper['/restart'] = ['callback' => 'retRestartProcess'];
$routerMapper['/kill'] = ['callback' => 'retKillWorkerProcess'];
$routerMapper['/status'] = ['callback' => 'retNetcoolInstantStatus'];
$routerMapper['/query'] = ['callback' => 'retDirectGokvQuery'];
$routerMapper['/get/qradar'] = ['callback' => 'retQradarLogFilterForGrafana'];
$routerMapper['/get/qradar/status'] = ['callback' => 'retQradarInstantStatusSearch'];
$routerMapper['/get/info'] = ['callback' => 'retOMNIbusSignalForGrafana'];
$routerMapper['/get/cache'] = ['callback' => 'retSolarWindsNPMMapper'];
$routerMapper['/get/allsensor/temp'] = ['callback' => 'retCenterScapeBulkQuery'];
$routerMapper['/get/allsensor/temperature'] = ['callback' => 'retCenterScapeBulkQuery'];
$routerMapper['/get/allsensor/humid'] = ['callback' => 'retCenterScapeBulkQuery'];
$routerMapper['/get/allsensor/humidity'] = ['callback' => 'retCenterScapeBulkQuery'];
$routerMapper['/get/allsensor/fluid'] = ['callback' => 'retCenterScapeBulkQuery'];
ksort($routerMapper);

$resolveRetMapper = [
    'json' => 'application/json; charset=utf-8',
    'html' => 'text/html; charset=utf-8',
    'text' => 'text/plain; charset=utf-8',
];
function resolveRet($conn, $statusCode, $type, $ret) {
    global $resolveRetMapper;
    $schema = ($type == 'json') ? json_encode($ret, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : $ret;

    $response = new Response($statusCode, [
        'Content-Type' => $resolveRetMapper[$type],
    ], $schema);

    $conn->send($response);
}

function router($url, $conn, $req) {
    global $routerMapper;

    if (array_key_exists(strtolower($url), $routerMapper))  $routerMapper[strtolower($url)]['callback']($conn, $req);

    routerAutoTrim(strtolower($url), $conn, $req);

    resolveRet($conn, 501, 'html', '<h1>API Server</h1>Error! Requested API method/invoker not implemented.<br>');
}

function routerAutoTrim($url, $conn, $req) {
    global $routerMapper;

    $lastSlashPos = strrpos($url, '/');
    $schema = substr($url, 0, $lastSlashPos);
    if (array_key_exists($schema, $routerMapper))   $routerMapper[$schema]['callback']($conn, $req);
}

function retProcessUptime($conn, $req) {
    global $bootCnt, $uptimeSince;
    ++$bootCnt;

    $counter = api_once("http://localhost:9000/get/Uptime:Netcool");
    $uptime_min = $counter * 5 * 0.01666;
    $uptime_hr = $uptime_min * 0.01666;
    $uptime_day = $uptime_hr * 0.04166;

    $uptime_min = round($uptime_min, 4);
    $uptime_hr = round($uptime_hr, 4);
    $uptime_day = round($uptime_day, 2);

    if ($uptime_min >= 59.9999) {
        $uptime_min = 0;
        $uptime_hr += 1;
    }

    if ($uptime_hr >= 24) {
        $uptime_hr = 0;
        $uptime_day += 1;
    }

    $ret = [
        "health"=> "up",
        "current system datetime"=> date("Y-m-d").' '.date("H:i:sA"),
        "up minutes"=> $uptime_min,
        "up hours"=> $uptime_hr,
        "up days"=> $uptime_day,
        "up has been"=> floor($uptime_day).' Day '.floor($uptime_hr).' Hour '.floor($uptime_min).' Minute',
        "alive"=> $uptimeSince,
    ];

    resolveRet($conn, 200, 'json', $ret);
}

function retRestartProcess($conn, $req) {
    go(function() {
        api_once("http://localhost:9000/put/Uptime:Netcool/0");

        $timestamp = date('Y-m-d H:i:sA', time());
        $shell = <<< EOF
#!/bin/sh
/data/pbin /data/endpoint stop
rm -rf /data/netcool.json
rm -rf /data/cs.json
rm -rf /data/qradar.json
nohup /data/pbin -c /data/php.ini /data/endpoint restart &
#nohup /data/pbin -c /data/php.ini /data/endpoint start -d 2&1
echo "executed $timestamp" > /dev/shm/shutdown.mark
EOF;
        Coroutine::writeFile('/dev/shm/shutdown.cmd', $shell, FILE_APPEND);
        //passthru('nohup sh /dev/shm/shutdown.cmd > /dev/shm/std.out 2>&1 &');

        Worker::stopAll();
    });
}

function retKillWorkerProcess($conn, $req) {
    global $worker1;

    Worker::stopAll();
    $worker1->stop();    
}

function retProcessCounter($conn, $req) {
    global $bootCnt;
    ++$bootCnt;

    resolveRet($conn, 200, 'html', $bootCnt);
}

function retNetcoolInstantStatus($conn, $req) {
    global $bootCnt;
    ++$bootCnt;

    go(function() use($conn, $req) {
        $fp = Coroutine::readFile('/data/netcool.json');

        if (!$fp) {
            resolveRet($conn, 500, 'html', 'IBM Tivoli Netcool/OMNIbus cache not synchronized yet.');
        } else {
            $fetch = str_replace('\"', ' ', $fp);
            $fetch = str_replace('\\', ' ', $fetch);
            $fetch = stripslashes(stripcslashes(urldecode($fetch)));
        }
    
        $raw = json_decode($fetch, true);
    
        if (!$raw) {
            resolveRet($conn, 500, 'html', 'Error parsing JSON output retrieved from IBM Tivoli Netcool/OMNIbus cache.');
        }
    
        $json = $raw['rowset']['rows'];
    
        $compose_cnt = count($json) -1;
    
        $compose = null;
    
        for ($i=0; $i<=$compose_cnt; ++$i) {
            $compose[$i]['RowID'] = ($i + 1);
            $compose[$i]['Acknowledged'] = $json[$i]['Acknowledged'];
            $compose[$i]['Severity'] = $json[$i]['Severity'];
            $compose[$i]['Node'] = $json[$i]['Node'];
            $compose[$i]['ServerName'] = $json[$i]['ServerName'];
            $compose[$i]['AlertGroup'] = $json[$i]['AlertGroup'];
            $compose[$i]['NodeAlias'] = $json[$i]['NodeAlias'];
            $compose[$i]['Agent'] = $json[$i]['Agent'];
            $compose[$i]['Manager'] = $json[$i]['Manager'];
            $compose[$i]['Identifier'] = $json[$i]['Identifier'];
            $compose[$i]['FirstOccurrence_raw'] = $json[$i]['FirstOccurrence'];
            $compose[$i]['FirstOccurrence'] = date('Y-m-d H:i:s', $json[$i]['FirstOccurrence']);
            $compose[$i]['LastOccurrence_raw'] = $json[$i]['LastOccurrence'];
            $compose[$i]['LastOccurrence'] = date('Y-m-d H:i:s', $json[$i]['LastOccurrence']);
            $compose[$i]['Summary'] = $json[$i]['Summary'];
            $compose[$i]['ExtendedAttr'] = $json[$i]['ExtendedAttr'];
        }
    
        resolveRet($conn, 200, 'json', $compose);
    });

    Coroutine::sleep(1);
}

function retDirectGokvQuery($conn, $req) {
    global $bootCnt;
    ++$bootCnt;

    $url = explode('/', $req->path());
    $param = stripslashes(stripcslashes(urldecode($url[2])));

    $raw = api_once("http://localhost:9000/get/$param");

    $fromGokv['index'] = $param;
    $fromGokv['raw_gokv_index'] = $url[2];
    $fromGokv['value'] = $raw;

    resolveRet($conn, 200, 'json', $fromGokv);
}

function retQradarLogFilterForGrafana($conn, $req) {
    global $bootCnt;
    ++$bootCnt;

    go(function() use($conn, $req) {
        $fp = Coroutine::readFile('/data/qradar.json');

        if (!$fp) {
            resolveRet($conn, 500, 'html', 'IBM Security QRadar SIEM cache not synchronized yet.');
        } else {
            $parse = str_replace('\\n', "", $fp);
            $parse = str_replace('\\', "", $parse);
        }
    
        $json = json_decode($parse, true);
    
        if (!$json) {
            resolveRet($conn, 500, 'html', 'Error parsing JSON output retrieved from IBM Security QRadar SIEM cache.');
        }
    
        $filter = $req->queryString();
        $filter = explode('filter=', $filter);
    
        $whiteList = [
            'count', ':', '\'', '|', '@', '\\', '"'
        ];
        $filter = sanitize(urldecode($filter[1]), $whiteList);
    
        // For Grafana Dashboard widget Web API
        foreach ($json as $k => $v) {
            if ($filter == '') {
                $ret['SIEM_found'] = false;
                break 1;
            }
    
            if (strpos($v['description'], $filter) === false)   continue 1;
        
            if ($v['severity'] > 0) {
                $ret['SIEM'] = 2;
                $ret['SIEM_found'] = true;
                $ret['grafana_dashboard_trafficLight_signal'] = "🔴【紅燈】Red Light";
                break 1;
            }
        }
    
        if (@$ret['SIEM_found'] == true) {
            $ret['filter'] = $filter;
            $ret['result'] = 'record(s) found with filter';
    
            resolveRet($conn, 200, 'json', $ret);
        } else {
            $ret['SIEM'] = 0;
            $ret['SIEM_found'] = false;
            $ret['grafana_dashboard_trafficLight_signal'] = "🟢【綠燈】Green Light";
            $ret['filter'] = $filter;
            $ret['result'] = 'no match record(s) found with filter';
    
            resolveRet($conn, 200, 'json', $ret);
        }
    });

    Coroutine::sleep(1);
}

function retQradarInstantStatusSearch($conn, $req) {
    global $bootCnt;
    ++$bootCnt;

    go(function() use($conn, $req) {
        $fp = Coroutine::readFile('/data/qradar.json');

        if (!$fp) {
            resolveRet($conn, 500, 'html', 'IBM Security QRadar SIEM cache not synchronized yet.');
        } else {
            $parse = str_replace('\\n', "", $fp);
            $parse = str_replace('\\', "", $parse);
        }
    
        $json = json_decode($parse, true);
    
        if (!$json) {
            resolveRet($conn, 500, 'html', 'Error parsing JSON output retrieved from IBM Security QRadar SIEM cache.');
        }
    
        $filter = $req->queryString();
        $filter = explode('filter=', $filter);
    
        $whiteList = [
            'count', ':', '\'', '|', '@', '\\', '"'
        ];
        $filter = sanitize(urldecode($filter[1]), $whiteList);
    
        $rowID = 0;
        foreach ($json as $k => $v) {
            if (strpos($v['description'], $filter) === false)   continue 1;
    
            $ret[$rowID]['Row ID'] = $rowID;
    
            $ret[$rowID]['severity'] = $v['severity'];
            $ret[$rowID]['description'] = $v['description'];
            $ret[$rowID]['id'] = $v['id'];
            $ret[$rowID]['offense_source'] = $v['offense_source'];
            $ret[$rowID]['start_time'] = $v['start_time'];
            $ret[$rowID]['start_time (Readable)'] = date('Y-m-d H:i:s', (int)($v['start_time'] / 1000) );
    
            $rowID++;
        }
    
        resolveRet($conn, 200, 'json', $ret);
    });

    Coroutine::sleep(1);
}

function retCenterScapeBulkQuery($conn, $req) {
    global $bootCnt;
    ++$bootCnt;

    $url = explode('/', $req->path());
    $type = stripslashes(stripcslashes(strtolower($url[3])));
    $ident = stripslashes(stripcslashes(urldecode($url[4])));

    $fp = file_get_contents('/data/cs.json');

    if (!$fp) {
        resolveRet($conn, 500, 'html', 'CenterScape cache not synchronized yet.');
    } else {
        $parse = str_replace('\"', "", $fp);
        $parse = str_replace('\\', "", $parse);
    }

    $raw = json_decode($parse, true);

    if (!$raw) {
        resolveRet($conn, 500, 'html', 'Error parsing JSON output retrieved from IBM Security QRadar SIEM cache.');
    }

    if (strpos($ident, ',') !== false) {
        $got = ',';
    } elseif (strpos($ident, '+') !== false) {
        $got = '+';
    } else {
        // Only one record retrieved.
        $got = '';
    }

    if ($got != '') {
        $import = explode($got, $ident);

        foreach ($import as $k => $v) {
            $cnt_raw = count($raw) -1;
            for ($i=0; $i<=$cnt_raw; ++$i) {
                // Filter-out the valid payload
                if (strpos($raw[$i]['$aName'], $v) !== false AND $v != '') {
                    $list[$v] = $i;
                    $list_val[] = $v;
                }
            }
        }

        foreach ($list_val as $v) {
            $idx = $list[$v];
            $str_temp = '溫度 temp temperature $aassettemperature room_temperature';
            if (strpos($str_temp, $type) !== false) {
                if ($raw[$idx]['$aAssetTemperature']) {
                    $ret[] = [
                        'sensor'=> "$v TEMP",
                        'data'=> $raw[$idx]['$aAssetTemperature'],
                    ];
                }

                if ($raw[$idx]['MIN_ROOM_TEMPERATURE']) {
                    $cal_avg_temp = ($raw[$idx]['MIN_ROOM_TEMPERATURE'] + $raw[$idx]['MAX_ROOM_TEMPERATURE']) / 2;
                    $ret[] = [
                        'sensor'=> "$v TEMP",
                        'data'=> $cal_avg_temp,
                    ];
                }

                if ($raw[$idx]['TEMP']) {
                    $ret[] = [
                        'sensor'=> "$v TEMP",
                        'data'=> $raw[$idx]['TEMP'],
                    ];
                }
            }

            $str_humid = '濕度 溼度 humi humid humidity $aassethumidity room_humidity';
            if (strpos($str_humid, $type) !== false) {
                if ($raw[$idx]['$aAssetHumidity']) {
                    $ret[] = [
                        'sensor'=> "$v HUMID",
                        'data'=> $raw[$idx]['$aAssetHumidity'],
                    ];
                }

                if ($raw[$idx]['MIN_ROOM_HUMIDITY']) {
                    $cal_avg_humid = ($raw[$idx]['MIN_ROOM_HUMIDITY'] + $raw[$idx]['MAX_ROOM_HUMIDITY']) / 2;
                    $ret[] = [
                        'sensor'=> "$v HUMID",
                        'data'=> $cal_avg_humid,
                    ];
                }

                if ($raw[$idx]['HUMI']) {
                    $ret[] = [
                        'sensor'=> "$v HUMID",
                        'data'=> $raw[$idx]['HUMI'],
                    ];
                }
            }

            $str_fluid = 'fluid 漏水 水 液體 滲漏';
            if (strpos($str_fluid, $type) !== false) {
                if (isset($raw[$idx]['$aAssetFluid'])) {
                    if ($raw[$idx]['$aAssetFluid'] == false) {
                        $ret[] = [
                            'sensor'=> "$v 🟢OK",
                            'data'=> 0,
                        ];
                    } else {
                        $ret[] = [
                            'sensor'=> "$v 🔴LEAK",
                            'data'=> 1,
                        ];
                    }
                }
            }
        }
    } else {
        $sensor = $ident;

        $cnt_raw = count($raw) -1;
        for ($i=0; $i<=$cnt_raw; ++$i) {
            if (strpos($raw[$i]['$aName'], $ident) !== false) {
                foreach ($raw[$i] as $k => $v) {
                    $res[$k] = $v;
                }
            }
        }

        if ($ident) {
            $str_temp = '溫度 temp temperature $aassettemperature room_temperature';
            if (strpos($str_temp, $type) !== false) {
                if ($res['$aAssetTemperature']) {
                    $ret[] = [
                        'sensor'=> "$sensor TEMP",
                        'data'=> $res['$aAssetTemperature'],
                    ];
                }

                if ($res['MIN_ROOM_TEMPERATURE']) {
                    $cal_avg_temp = ($res['MIN_ROOM_TEMPERATURE'] + $res['MAX_ROOM_TEMPERATURE']) / 2;
                    $ret[] = [
                        'sensor'=> "$sensor TEMP",
                        'data'=> $cal_avg_temp,
                    ];
                }

                if ($res['TEMP']) {
                    $ret[] = [
                        'sensor'=> "$sensor TEMP",
                        'data'=> $res['TEMP'],
                    ];
                }

                resolveRet($conn, 200, 'json', $ret);
            }

            $str_humid = '濕度 溼度 humi humid humidity $aassethumidity room_humidity';
            if (strpos($str_humid, $type) !== false) {
                if ($res['$aAssetHumidity']) {
                    $ret[] = [
                        'sensor'=> "$sensor HUMID",
                        'data'=> $res['$aAssetHumidity'],
                    ];
                }

                if ($res['MIN_ROOM_HUMIDITY']) {
                    $cal_avg_humid = ($res['MIN_ROOM_HUMIDITY'] + $res['MAX_ROOM_HUMIDITY']) / 2;
                    $ret[] = [
                        'sensor'=> "$sensor HUMID",
                        'data'=> $cal_avg_humid,
                    ];
                }

                if ($res['HUMI']) {
                    $ret[] = [
                        'sensor'=> "$sensor HUMID",
                        'data'=> $res['HUMI'],
                    ];
                }

                resolveRet($conn, 200, 'json', $ret);
            }

            $str_fluid = 'fluid 漏水 水 液體 滲漏';
            if (strpos($str_fluid, $type) !== false) {
                if (isset($res['$aAssetFluid'])) {
                    if ($res['$aAssetFluid'] == false) {
                        $ret[] = [
                            'sensor'=> "$sensor 🟢OK",
                            'data'=> 0,
                        ];
                    } else {
                        $ret[] = [
                            'sensor'=> "$sensor 🔴LEAK",
                            'data'=> 1,
                        ];
                    }
                }

                resolveRet($conn, 200, 'json', $ret);
            }
        }

    }

    resolveRet($conn, 200, 'json', $ret);
}

function retOMNIbusSignalForGrafana($conn, $req) {
    global $bootCnt;
    ++$bootCnt;

    go(function() use($conn, $req) {
        $url = explode('/', $req->path());
        $param = stripslashes(stripcslashes(urldecode($url[3])));
        $fetch = api_once("http://localhost:9000/get/$param");
    
        $parse = explode(',', $fetch);
        $status = $parse[1];
        if ($status == "0") {
            $msg = 'target is normal';
        } elseif ($status == "2") {
            $msg = 'target is alarming';
        } else {
            // Presume it is =1.
            $msg = 'target is not defined in table';
        }
    
        if ($parse[0] == 'error') {
            $payload = [
                $param => 1,
                "status"=> "404 Not found!",
                "msg"=> $msg,
            ];
        } elseif ($parse[0] == 'instance') {
            $payload = [
                $param => intval($parse[1]),
                "status"=> "$status",
                "type"=> "instance",
                "msg"=> $msg,
            ];
        } else {
            // elseif ($parse[0] == 'group')
            $payload = [
                 $param => intval($parse[1]),
                "status"=> "$status",
                "type"=> "group",
                "msg"=> $msg,
            ];
        }
    
        resolveRet($conn, 200, 'json', $payload);
    });

    Coroutine::sleep(1);
}

function retSolarWindsNPMMapper($conn, $req) {
    // Workaround Aid for SolarWinds NPM connection glitch with Grafana
    global $bootCnt;
    ++$bootCnt;

    // Load-up connection settings
    $loadConfig = file_get_contents('/data/auth.json');
    $loadRAW = str_replace('\\', '', $loadConfig);
    $loadRAW = stripslashes(stripcslashes($loadRAW));
    $load = json_decode($loadRAW, true);
    unset($loadConfig, $loadRAW);
    $timeout = 10;   // In seconds unit

    $url_raw = explode('/', $req->path());
    $findCacheIdx = stripslashes(stripcslashes(urldecode($url_raw[3])));

    if ($load) {
        $key = substr(md5($findCacheIdx), 0, 7);
        $usr = $load['solarwinds_username'];

        global $iv_path, $key;
        $pwd = decrypt_aes256($load['solarwinds_password'], $key);

        if (array_key_exists($findCacheIdx, $load['cache'])) {
            $url = $load['cache'][$findCacheIdx];

            system("curl -k --ciphers DEFAULT@SECLEVEL=1 '$url' -m $timeout -u $usr:$pwd -Lo " . $key.'.txt' . ' >/dev/shm/std.out 2>&1');

            $fp = file_get_contents("/data/$key.txt");
            if (!$fp) {
                $timeout = 10;
                // Second attempt without --ciphers
                system("curl -k '$url' -m $timeout -u $usr:$pwd -Lo $key.txt" . ' >/dev/shm/std.out 2>&1');

                $fp = file_get_contents("/data/$key.txt");

                if (!$fp) {
                    // Still deemed as anomaly in signal and returns
                    $ret['Status'] = 1;
                    $ret['status'] = 1;
                 
                    resolveRet($conn, 200, 'json', $ret);
                }
            }

            $read = json_decode($fp, true);
            if (!$read) {
                $ret['Status'] = 1;
                $ret['status'] = 1;

                resolveRet($conn, 200, 'json', $ret);
            }

            if (!$read['results'][0]) {
                $ret['Status'] = 1;
                $ret['status'] = 1;

                resolveRet($conn, 200, 'json', $ret);
            }

            if (array_key_exists('Status', $read['results'][0])) {
                $ret['Status'] = $read['results'][0]['Status'];
                $ret['status'] = $read['results'][0]['Status'];

                if ($read['results'][0]['Status'] == null) {
                    $ret['Status'] = 1;
                    $ret['status'] = 1;
                } else {
                    $sig = sig_npm(intval($read['results'][0]['Status']));
                    $ret['Status'] = $sig;
                    $ret['status'] = $sig;
                }

                resolveRet($conn, 200, 'json', $ret);
            }

            if (array_key_exists('status', $read['results'][0])) {
                $ret['Status'] = $read['results'][0]['Status'];
                $ret['status'] = $read['results'][0]['Status'];

                if ($read['results'][0]['Status'] == null) {
                    $ret['Status'] = 1;
                    $ret['status'] = 1;
                } else {
                    $sig = sig_npm(intval($read['results'][0]['Status']));
                    $ret['Status'] = $sig;
                    $ret['status'] = $sig;
                }

                resolveRet($conn, 200, 'json', $ret);
            }
                // The json raw doesn't exist!
                $ret['Status'] = 1;
                $ret['status'] = 1;

                resolveRet($conn, 200, 'json', $ret);
        } else {
            resolveRet($conn, 404, 'html', 'Requested cache index name not exists in SolarWinds NPM Mapping Table!');
        }
    }
}

function task_centerscape() {
    global $iv_path, $key;

    // Load-up connection settings
    $fp = file_get_contents('/data/auth.json');
    $raw = str_replace('\\', '', $fp);
    $raw = stripslashes(stripcslashes($raw));
    $d = json_decode($raw, true);
    unset($fp, $raw);

    // Retrieve update from Centerscape
    $url = $d['centerscape_url'];
    $usr = $d['centerscape_username'];
    $pwd = decrypt_aes256($d['centerscape_password'], $key);

    system("curl -k --ciphers DEFAULT@SECLEVEL=1 '$url' -u $usr:$pwd -Lo cs.json" . ' >/dev/shm/std.out 2>&1');
}

function task_omnibus() {
    global $iv_path, $key;

    // Load-up connection settings
    $fp = file_get_contents('/data/auth.json');
    $raw = str_replace('\\', '', $fp);
    $raw = stripslashes(stripcslashes($raw));
    $d = json_decode($raw, true);
    unset($fp, $raw);

    // Load-up key-mapping table for #1 and #5 Grafana dashboard handlings
    $fp = file_get_contents('/data/manifest.json');
    $raw = str_replace('\\', '', $fp);
    $raw = stripslashes(stripcslashes(urldecode($raw)));
    $table = json_decode($raw, true);
    unset($fp, $raw);

    foreach ($table['instance'] as $v) {
        $update[$v] = "instance,0";
    }

    foreach ($table['group'] as $k => $v) {
        $update[$k] = "group,0";
    }

    api_post("http://localhost:9000/bulkPut", $update);

    // Retrieve update from Omnibus
    $url = $d['netcool_url'];
    $usr = $d['netcool_username'];
    $pwd = decrypt_aes256($d['netcool_password'], $key);

    $useTimeFilter = $d['netcool_limit_minutes_filter_name'];
    if ($useTimeFilter != '') {
        $min = (int)$d['netcool_limit_minutes'];
        $currentSysTime = time();
        $newTimeSchema = $currentSysTime - ($min * 60);
        $url .= $useTimeFilter . $newTimeSchema;
    }

    system("curl -k --ciphers DEFAULT@SECLEVEL=1 $url -u $usr:$pwd -Lo netcool.json" . ' >/dev/shm/std.out 2>&1');

    // Parse the cache and refresh
    $fp = file_get_contents('/data/netcool.json');
    $fetch = str_replace('\"', '', $fp);
    $fetch = str_replace('\\', ' ', $fetch);
    $job = stripslashes(stripcslashes(urldecode($fetch)));
    $raw = json_decode($job, true);
    $json = $raw['rowset']['rows'];
    unset($fp, $fetch, $job, $raw);

    $cnt = count($json) -1;
    for ($i=0; $i<=$cnt; ++$i) {
        $ack = intval($json[$i]['Acknowledged']);
        if ($ack == 0) {
            $host = $json[$i]['Node'];
            $host = str_replace(' ', '', $host);

            $notify[$host] = "instance,2";  // Red

            foreach ($table['group'] as $k => $v) {
                // Added verification condition
                if (strlen($v) <= 5)    continue 1;

                // Probable unknown bugfix attempt
                /*if (strpos($v, $host) !== false) {
                    $notify[$k] = "group,2";
                }*/

                $read = explode(',', $v);
                foreach ($read as $idx => $val) {
                    if (strlen($val) == 0)  continue 1;

                    if ($val == $host)  $notify[$k] = "group,2";
                }
            }
        }
    }

    api_post("http://localhost:9000/bulkPut", $notify);
}

function task_qradar() {
    global $iv_path, $key;

    // Load-up connection settings
    $fp = file_get_contents('/data/auth.json');
    $raw = str_replace('\\', '', $fp);
    $raw = stripslashes(stripcslashes($raw));
    $d = json_decode($raw, true);
    unset($fp, $raw);

    // Retrieve update from IBM Qradar
    $url = $d['qradar_uri'];
    $secret = decrypt_aes256($d['qradar_sec'], $key);

    $min = (int)$d['qradar_limit_minutes'];
    $currentSysTime = time();
    $newTimeSchema = $currentSysTime - ($min * 60);
    $url .= $newTimeSchema;

    $timeout = 20;

    system("curl -k -s -X GET --ciphers DEFAULT@SECLEVEL=1 '$url' -H \"SEC: $secret\" -H \"Version: 19.0\" -H \"Accept: application/json\" -m $timeout -Lo qradar.json" . ' >/dev/shm/std.out 2>&1');
}

function sig_npm($import) {
    // SolarWinds NPM ["status"] Grafana 信號處理：0=綠燈、1=紅燈
    $import = intval($import);
    switch((int)$import) {
        case 1:
            $ret = 0;
            break 1;
        case 2:
        case 14:
            $ret = 1;
            break 1;
        case 3:
            $ret = 0;
            break 1;
        default:
            $ret = 0;
            break 1;
    }

    return $ret;
}

function api_once($entrypoint) {
    $entrypoint = str_replace(' ', '%20', $entrypoint);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT_MS, 1000);
    curl_setopt($ch, CURLOPT_URL, $entrypoint);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    //curl_setopt($ch, CURLOPT_USERAGENT, 'CMS API SERVER');
    //curl_setopt($ch, CURLOPT_REFERER, 'SELF');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $ret = curl_exec($ch);
    curl_close($ch);

    return $ret;
}

function api_post($entrypoint, $jsonArr) {
    $json = json_encode($jsonArr);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $entrypoint);
    //curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
    curl_setopt($ch, CURLOPT_TIMEOUT, 8);
    //curl_setopt($ch, CURLOPT_USERAGENT, 'CMS API SERVER');
    //curl_setopt($ch, CURLOPT_REFERER, 'SELF');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    /*
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'Content-Length: ' . strlen($json)
    )); */
    $ret = curl_exec($ch);
    curl_close($ch);

    return $ret;
}

function sanitize($input_plaintext, $whiteList = false) {
    $keyTable = [
        /* Generic symbolic operators */
        '{', '}', '[', ']', '<', '>', '!', '@', '#', '$', '~', '`', '\\', '/', '^', ':', ';', '|', '?', '\'', '"',
        /* Generic comparison operators */
        '==', '===', '+=', '-=', '*=', '%=',
        /* Generic description markers */
        '<!--', '-->', '/*', '*/',
        /* Target URI file extensions */
        '.htm', '.shtm', '.xhtm', '.xml', '.js', '.ts', '.typescript', '.tisscript', '.tiscript',
        '.cgi', '.php', '.react', '.vue', '.css', '.sass', '.asp', '.so', '.dll', '.jsp', '.jsx',
        '.java', '.py', '.cpy', '.exe', '.bin', '.7z', '.zip', '.gz', '.tar', '.tar.gz', '.rar',
        '.xz', '.wim', '.gzip', '.gz', '.bzip', '.rb', '.cs', '.ascx', '.cu', '.c', '.cpp', '.json',
        '.cache', '.text', '.txt', '.doc', '.ppt', '.xls', '.msaccess', '.access', '.csv', '.ini', '.pbx',
        '.key', '.cert', '.pl', '.dart', '.kt', '.go', '.cgo', '.lz', '.z', '.tar.xz', '.jvm', '.dump', '.jar',
        '.war', '.apk', '.deb', '.msi', '.rpm', '.bash', '.shell', '.sh', '.perl', '.cab', '.img', '.iso', '.rss',
        '.atom', '.md', '.git', '.jpg', '.jpeg', '.gif', '.png', '.bmp', '.drawio', '.draw.io', '.svg', '.asm', '.wasm',
        '.mp', '.avi', '.m3u4', '.mkv', '.dl', '.download', '.mov', '.wmv', '.flv', '.flash', '.wav', '.wmv', '.ogg',
        '.pdf', '.ico', '.rtf', '.view', '.torrent', '.icx', '.ics', '.per', '.pear', 'servlet',
        /* STD Standard Library keywords, includes: (std, stdio, stdin, stdout, stderr) + err(-or) */
        'std', 'err',
        /* PHP system call command (# Command Injection) */
        'system', 'exec', 'shell_exec', 'passthru', 'shell', 'cmd', 'command', 'pipe',
        /* PHP file operation entrypoints */
        'file', 'file_get_content', 'file_put_content', 'file_exists', 'fileowner', 'isfile', 'isdir', 'filesize',
        'filetype', 'feof', 'fopen', 'fscanf', 'fseek', 'fread', 'fwrite', 'fclose', 'fstat', 'fgetc', 'fgets', 'fsockopen',
        'socket', 'curl',
        /* User-generated request keywords */
        '_SERVER', '_REQUEST', '_GET', '_POST', '_FILE',
        /* PHP crucial language keywords */
        'require', 'require_once', 'include', 'include_once', 'phpinfo', 'error_reporting', 'die', 'echo', 'print',
        'eval', 'var_dump', 'var_export', 'var_print', 'var_printf', 'print_r', 'array',
        'preg_replace', 'str_replace', 'str_ireplace', 'preg_match', 'str_match', 'array_search', 'substr', 'bin2hex', 'hex2bin',
        'base64_encode', 'base64_decode', 'json_encode', 'json_decode', 'crc32', 'crypt', 'mb_string',
        'md5', 'sha', 'jwt', 'urlencode', 'urldecode', 'base64', 'strlen', 'trim', 'mcrypt', 'hash', 
        'continue', 'break', 'sleep', 'goto', 'skip',
        'switch', 'openssl', 'rand', 'random', 'random_bytes', 'jump', 'exit', 'quit', 'dim', 'declare', 'const',
        'fn', 'func', 'function', 'foo', 'bar', 'tool', 'load', 'isload', 'REQUEST', 'GET', 'POST',
        'header', 'body', 'browser', 'agent', 'count', 'execute', 'gen', 'generate', 'buf', 'buffer',
        '__construct', '__destruct', 'yield', 'generator', 'fiber', 'in_array', 'encrypt', 'decrypt', 'case', 'exception', 'catch',
        '__sleep', 'serialize', '__wakeup', 'unserialize',
        'timestamp', 'format', 'load_file', 'outfile', 'text', 'delay', 'sysdate', 'systime', 'having', 'throw', 'throw new', 'throw new exception', 'new class',
        /* Partial SQL raw/native query string */
        'order', 'distinct', 'above', 'among', 'below', 'equal', 'increase', 'decrease',
        'restrict', 'limit', 'asc', 'dsec', 'begin', 'transact', 'replace', 'wait', 'when', 'where', 'row', 'distinctrow',
        'col', 'column', 'sort', 'union', 'select', 'insert', 'into', 'capture',
        /* Javascript(JS) front-end keywords */
        'import', 'export', 'input', 'output', 'async', 'var', 'let', 'type', 'style', 'class', 'DOMDocument',
        'document', 'documentation', 'loadXML', 'rewrite', 'redirect', 're-write', 're-direct', 'getElementsBy',
        '->', 'listen', 'listener', 'img', 'href', 'src', 'alert', 'onerr', 'onerror', 'log.',
        'console', 'console.', 'onload', 'onmouse', 'onkey', 'onevent', 'onexit', 'onkeyup', 'script', 'javascript',
        'object', 'iframe', 'hidden', 'xss', 'debug', 'identifier', 'data', 'XMLHttpRequest',
        'ActiveXObject','onreadystatechange', 'readyState', 'responseText', 'length', 'nodeType', 'nodeValue', 'childNodes',
        '.replace', '_replace', '.insert', '_insert', '.remove', '_remove', '.add', '_add', '.del', '_del',
        '.delete', '_delete', '.update', '_update', '.put', '_put', '.rm', '_rm', 'dba', 'dbausr', 'dbauser', 'dba_usr', 'dba_user',
        'admin', 'root', 'home', 'path', 'directory', 'db', 'database', 'upload',
        /* Network entrypoints */
        'localhost', '127.0.0.1', 'ping',
        /* File descriptors (# pseudo protocol handlers) */
        'http://', 'https://', 'tcp://', 'udp://', 'quic', 'ssl://', 'tls://', 'websocket://', 'ws://', 'php://',
        'file://', 'socket://', 'txt://', 'text://', 'data://', 'dict://', 'sys://', 'system://',
        'proto://', 'protocol://', 'access://', 'db://', 'dba://', 'ftp://', 'sftp://', 'scp://',
        /* Linux partially crucial syscall() commands */
        'passwd', 'useradd', 'userdel', 'usermod', 'adduser', 'deluser', 'moduser', 'mkdir', 'mkfile', 'touch',
        'wget', 'yum', 'apt', 'update', 'upgrade', 'chmod', 'chown', 'chgrp', 'link', 'unlink', 'ulink', 'rmdir',
        '/etc/', 'shutdown', 'restart', 'reboot', 'bash', 'crontab', './', 'force', 'forcibly', 'rm -r', 'rm -rf',
        '/bin/', '/boot/', '/data/', '/dev/', '/home/', '/lib/', '/lib64/', '/media/', '/mnt/', '/opt/', '/proc/',
        '/root/', '/run/', '/sbin/', '/srv/', '/sys/', '/tmp/', '/usr/', '/var/'
    ];

    if ($whiteList !== false) {
        if ($whiteList) {
            $keyTable = array_diff($keyTable, $whiteList);
            return str_ireplace($keyTable, '', $input_plaintext);
        }
    }

    return str_ireplace($keyTable, '', $input_plaintext);
}


Worker::$eventLoopClass = 'Workerman\Events\Swoole';
Worker::$logFile = '/dev/shm/log.out';   // Default: workerman.log   =>  workerman自身相关的日志
Worker::$stdoutFile = '/dev/shm/std.out';   // Default: stdout.log   =>  输出日志, 如echo，var_dump等
Worker::runAll();